package com.example.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.employee.request.AddEmployeeReq;
import com.example.employee.model.Addresses;
import com.example.employee.model.Employee;
import com.example.employee.model.Incubatesoft;
import com.example.employee.model.Organization;
import com.example.employee.repository.EmployeeRepository;
import com.example.employee.repository.OrganizationRepository;

/**
 * The class contains the code logic for all the Employee related business flow
 * of the Service classes by implementing the EmployeeService interface. The class can
 * be annotated with @Component or @Service, but generally @Component is preferred.
 * 
 * @author Sharanya
 *
 */
@Component
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Override
	// getting all employees record by using the method findaAll() of CrudRepository
	public List<Employee> getAllEmployees() {
		List<Employee> employees = new ArrayList<Employee>();
		employeeRepository.findAll().forEach(employees1 -> employees.add(employees1));
		// employeeRepository.
		return employees;
	}

	@Override
	// getting a specific record by using the method findById() of CrudRepository
	public Employee getEmployeeById(int employeeId) {
		return employeeRepository.findById(employeeId).get();
	}

	@Override
	// saving a specific record by using the method save() of CrudRepository
	public void addEmployee(AddEmployeeReq employee) {
		Organization organization = new Organization();
		organization.setOrgId(employee.getOrgId());
		
		/*
		 * Addresses address = new Addresses();
		 * address.setAddress(employee.getAddress().getAddress());
		 * address.setCountry(employee.getAddress().getCountry());
		 * address.setPincode(employee.getAddress().getPincode());
		 */
		
		Employee emp = new Employee();
		emp.setEmployeeId(employee.getEmployeeId());
		emp.setEmployeeName(employee.getEmployeeName());
		emp.setEmployeeSalary(emp.getEmployeeSalary());
		emp.setOrganization(organization);
		
		employeeRepository.save(emp);

	}

	@Override
	// 
	public List<Employee> getEmployeeByPin(int pincode) {
		return null;
		//return employeeRepository.findByPincode(pincode);
		
	}

	@Override
	// updating a record
	public boolean updateEmployee(Employee employee, int employeeId) {

		if (employeeRepository.existsById(employeeId)) {
			employeeRepository.save(employee);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String retrieveWelcomeMessage() {
		return "Welcome !";
	}

	@Override
	public Employee getAllOrganizations() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	// Add a specific organization record by using the save().
	public boolean checkIfEmpExists(int employeeId) {
		return employeeRepository.existsById(employeeId);
	}

}
