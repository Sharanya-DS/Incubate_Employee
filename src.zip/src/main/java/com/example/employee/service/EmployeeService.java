package com.example.employee.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.employee.request.AddEmployeeReq;
import com.example.employee.model.Employee;
import com.example.employee.model.Organization;

/**
 * The interface is used to loose couple any Employee related business logic of
 * the Service classes. This interface contains project specific methods that
 * need to be implemented by the implementing classes.
 * 
 * @author Sharanya
 *
 */
@Service
public interface EmployeeService {

	// getting all employees record by using the method findaAll() of CrudRepository
	public List<Employee> getAllEmployees();

	// getting a specific record by using the method findById() of CrudRepository
	public Employee getEmployeeById(int employeeId);

	// saving a specific record by using the method save() of CrudRepository
	public void addEmployee(AddEmployeeReq addEmployeeReq);

	// 
	public List<Employee> getEmployeeByPin(int pincode);
	

	// updating a record
	public boolean updateEmployee(Employee employee, int employeeId);

	// 
	public String retrieveWelcomeMessage();
	
	public Employee getAllOrganizations();
	
	//checking if a particular organization exists for the given org id using the existsById of the CrudRepository
	public boolean checkIfEmpExists(int employeeId);
	
}
