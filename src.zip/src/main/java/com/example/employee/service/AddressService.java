package com.example.employee.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.employee.request.AddAddressReq;
import com.example.employee.model.Addresses;

/**
 * The interface is used to loose couple any Address related business logic of
 * the Service classes. This interface contains project specific methods that
 * need to be implemented by the implementing classes.
 * 
 * @author Sharanya
 *
 */
@Service
public interface AddressService {

	// Add a specific organization record by using the save().
	public void addAddresses(AddAddressReq addAddressReq);
	
	public List<Addresses> getAddressesByEmpIdAndOrgId(int employeeId, int orgId);

}
