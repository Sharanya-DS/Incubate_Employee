package com.example.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.employee.request.AddOrganizationReq;
import com.example.employee.model.Organization;


/**
 * The interface is used to loose couple any Organization related business logic of
 * the Service classes. This interface contains project specific methods that
 * need to be implemented by the implementing classes.
 * 
 * @author Sharanya
 *
 */
@Service
public interface OrganizationService {

	// Add a specific organization record by using the save().
	public void addOrganization(AddOrganizationReq org);

	// getting a specific record by using the method findById() of CrudRepository
	public Organization getOrganizationById(int orgId);
	
	//checking if a particular organization exists for the given org id using the existsById of the CrudRepository
	public boolean checkIfOrgExists(int orgId);
	
	
	public List<Organization> getAllOrganizations();
	
}
