package com.example.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.employee.request.AddOrganizationReq;
import com.example.employee.model.Employee;
import com.example.employee.model.Incubatesoft;
import com.example.employee.model.Organization;
import com.example.employee.repository.EmployeeRepository;
import com.example.employee.repository.OrganizationRepository;

/**
 * The class contains the code logic for all the Organization related business flow
 * of the Service classes by implementing the OrganizationService interface.
 * The class can be annotated with @Component or @Service, but generally
 * @Component is preferred.
 * 
 * @author Sharanya
 *
 */
@Component
public class OrganizationServiceImpl implements OrganizationService {

	@Autowired
	OrganizationRepository organizationRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Override
	// Add a specific organization record by using the save().
	public void addOrganization(AddOrganizationReq org) {
		Incubatesoft incubate = new Incubatesoft();
		incubate.setIncubateId(org.getIncubateId());
		
		Organization organization = new Organization();
		organization.setOrgId(org.getOrgId());
		organization.setOrgName(org.getOrgName());
		organization.setIncubatesoft(incubate);
		
		organizationRepository.save(organization);
	}

	@Override
	// Add a specific organization record by using the save().
	public boolean checkIfOrgExists(int orgId) {
		return organizationRepository.existsById(orgId);
	}

	@Override
	public Organization getOrganizationById(int orgId) {
		organizationRepository.findById(orgId);
		return null;
	}
	
	/*
	 * @Override public List<Organization> getAllOrganizations1() {
	 * List<Organization> organizations = new ArrayList<Organization>();
	 * List<Employee> employees = new ArrayList<Employee>();
	 * organizationRepository.findAll().forEach(organizations1 -> {
	 * employeeRepository.findByOrgId(organizations1.getOrgId()).forEach(employee1
	 * -> { System.out.println("EMployee details insode Org :::: " +
	 * employee1.getEmployeeId()); }); organizations.add(organizations1); });
	 * 
	 * return organizations; }
	 */
	
	@Override
	public List<Organization> getAllOrganizations() {
		List<Organization> organizations = new ArrayList<Organization>();
		List<Employee> employees = new ArrayList<Employee>();
		organizationRepository.findAll().forEach(organizations1 ->  organizations.add(organizations1));
				return organizations;
	}
}
