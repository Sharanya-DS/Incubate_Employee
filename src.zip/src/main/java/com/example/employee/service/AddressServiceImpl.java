package com.example.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.employee.request.AddAddressReq;
import com.employee.request.AddOrganizationReq;
import com.example.employee.model.Addresses;
import com.example.employee.model.Employee;
import com.example.employee.model.Incubatesoft;
import com.example.employee.model.Organization;
import com.example.employee.repository.AddressRepository;
import com.example.employee.repository.OrganizationRepository;

/**
 * The class contains the code logic for all the Address related business flow
 * of the Service classes by implementing the AddressService interface. The
 * class can be annotated with @Component or @Service, but generally
 * 
 * @Component is preferred.
 * 
 * @author Sharanya
 *
 */
@Component
public class AddressServiceImpl implements AddressService {

	@Autowired
	AddressRepository addressRepository;

	@Override
	public void addAddresses(AddAddressReq addAddressReq) {

		Employee employee = new Employee();
		employee.setEmployeeId(addAddressReq.getEmployeeId());

		Addresses address = new Addresses();
		address.setAddress(addAddressReq.getAddressString());
		address.setCountry(addAddressReq.getCountry());
		address.setId(addAddressReq.getAddressId());
		address.setPincode(addAddressReq.getPincode());
		address.setEmployee(employee);

		addressRepository.save(address);

	}

	@Override
	public List<Addresses> getAddressesByEmpIdAndOrgId(int employeeId, int orgId) {
		
		return addressRepository.findByemployeeId(employeeId);
		//return addressRepository.findAll();
	}

}
