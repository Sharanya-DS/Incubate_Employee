/**
 * 
 */
package com.example.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee.service.AddressService;
import com.example.employee.service.EmployeeService;
import com.example.employee.service.EmployeeServiceImpl;
import com.example.employee.service.OrganizationService;
import com.employee.request.AddAddressReq;
import com.employee.request.AddEmployeeReq;
import com.employee.request.AddOrganizationReq;
import com.example.employee.model.Addresses;
import com.example.employee.model.Employee;
import com.example.employee.model.Organization;
import com.example.employee.repository.OrganizationRepositoryImpl;

/**
 * 
 * This is the Controller Class. All requests from the layer above come here to
 * their corresponding methods based on the path.
 * 
 * @author Sharanya
 *
 */

@RestController
//@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	private EmployeeService empService;

	@Autowired
	private OrganizationService orgService;

	@Autowired
	private AddressService addressService;

	/**
	 * Method that gets called when the application starts with no specific url.
	 * This invokes {@link EmployeeServiceImpl empService} which returns a
	 * predefined welcome message.
	 * 
	 * @return the welcome message from the service.
	 */
	@RequestMapping
	public String welcome() {
		return empService.retrieveWelcomeMessage();
	}

	/**
	 * Method to add a new organization. This invokes
	 * {@link OrganizationServiceImpl orgService} which calls the
	 * OrganizationRepository to add the organization details.
	 * 
	 * @param organization the organization data that needs to be added to the
	 *                     organization.
	 * 
	 * @return the value of the newly added organization's Id.
	 */
	@PostMapping("/organization")
	private void addOrganization(@RequestBody AddOrganizationReq  addOrganizationReq) {
		orgService.addOrganization(addOrganizationReq);
		
	}

	/**
	 * Method to fetch all the organizations. This invokes
	 * {@link OrganizationServiceImpl orgService} which calls the
	 * OrganizationRepository to fetch all the organizations.
	 * 
	 * @return all the organizations present and their corresponding details.
	 */
	@GetMapping("/organization/get")
	public List<Organization> getAllOrganizations() {
		return orgService.getAllOrganizations();
	}

	/**
	 * Method to add Employee details for an organization.First, the method confirms
	 * if the organization exists and if it does,then adds the employee to it. This
	 * invokes {@link EmployeeServiceImpl empService} which calls the
	 * EmployeeRepository to get the employee details from the database using the
	 * pinCode as the search criteria.
	 * 
	 * @param orgId    the identification of a particular organization under which
	 *                 the employee needs to be added.
	 * @param employee the employee data that needs to be added to the organization.
	 * 
	 * @return the value of the newly added employee's Id.
	 */
	@PostMapping("/add")
	private String addEmployee(@RequestHeader(name = "ORGID", required = true) int orgId,
			@RequestBody AddEmployeeReq addEmployeeReq) {

		boolean orgExists = orgService.checkIfOrgExists(orgId);

		if (orgExists) {
			addEmployeeReq.setOrgId(orgId);
			empService.addEmployee(addEmployeeReq);
			return ("Employee " + addEmployeeReq.getEmployeeId() + " added successfully under the Organization. ");
		} else {
			return ("Employee " + addEmployeeReq.getEmployeeId() + " cannot be added as Organization does not exist. ");
		}

	}

	/**
	 * Method to add Employee address details for a particular employee working
	 * under an organization.First, the method confirms if the employee exists and
	 * if it does,the address to it. This invokes {@link EmployeeServiceImpl
	 * empService} which calls the EmployeeRepository to get the employee details
	 * from the database using the pinCode as the search criteria.
	 * 
	 * @param employeeId the identification of a particular employee to which the
	 *                   address needs to be added.
	 * @param addresses  the address that needs to be added to the employee
	 * 
	 * @return a confirmation string of whether the address was added to the
	 *         employee or not.
	 * 
	 */
	@PostMapping("/addresses/{employeeId}")
	private String addEmployeeAddresses(@PathVariable("employeeId") int employeeId,
			@RequestBody AddAddressReq addAddressReq) {

		boolean empExists = empService.checkIfEmpExists(employeeId);

		if (empExists) {			
			//addAddressReq.stream().forEach (address1 -> {
				//address1.setEmployeeId(employeeId);
			addAddressReq.setEmployeeId(employeeId);
				addressService.addAddresses(addAddressReq);				
			//});
			return ("Address(es) were added for the employee under the Organization ");
		} else {
			return ("Employee " + employeeId + " does not exist. Therefore address(es) cannot be added. ");
		}

	}

	/**
	 * Method to fetch Employee details for a specified pin code in the address. The
	 * method also fetches the corresponding organization details of the employee.
	 * This invokes {@link EmployeeServiceImpl empService} which calls the
	 * EmployeeRepository to get the employee details from the database using the
	 * pinCode as the search criteria.
	 * 
	 * @param pinCode a 6 digit pin code value for which the employee and their
	 *                corresponding organization details need to be fetched.
	 * @return the employee and organization details for the given pin code.
	 * 
	 */

	@GetMapping("/employee/{pinCode}")
	public List<Employee> getEmployeeByPin(@PathVariable("pinCode") int pinCode) {
		System.out.println("pinCode is :::::::::: " + pinCode);
		return null;
		//return empService.getEmployeeByPin(pinCode);
	}
 
	/**
	 * Method to fetch all the addresses for a specified employee id and
	 * organization id. The method checks if the employee exists and also checks is
	 * the employee exists under the given organization. If both are true, then it
	 * fetches the corresponding address details of the employee. This invokes
	 * {@link EmployeeServiceImpl empService} which calls the EmployeeRepository to
	 * get the employee details from the database using the employee id as the
	 * search criteria.
	 * 
	 * @param employeeId an unique identifier for each employee for which their
	 *                   corresponding addresses need to be fetched.
	 * @param orgId      an unique identifier for each organization for which their
	 *                   corresponding employee's addresses need to be fetched.
	 * @return all the available addresses for the given employee under the
	 *         organization.
	 * 
	 */
	@GetMapping("/employee")
	public List<Addresses> getAddressesByEmpIdAndOrgId(@RequestParam("employeeId") int employeeId,
			@RequestParam("orgId") int orgId) {
		System.out.println("employee id is :::::::::: " + employeeId);
		return addressService.getAddressesByEmpIdAndOrgId(employeeId, orgId);
	}

	/**
	 * Method to fetch all the employee details of a particular employee. The method
	 * checks if the employee exists and also checks is the employee exists under
	 * the given organization. If both are true, then it fetches the corresponding
	 * employee details. This invokes {@link EmployeeServiceImpl empService} which
	 * calls the EmployeeRepository to get the employee details from the database
	 * using the employee id as the search criteria.
	 * 
	 * @param employeeId an unique identifier for each employee for which their
	 *                   corresponding details need to be fetched.
	 * @param orgId      an unique identifier for each organization for which their
	 *                   corresponding employee's details need to be fetched.
	 * @return details of the particular employee under the organization.
	 * 
	 */

	/*
	 * @GetMapping("/employee/{pinCode}") public Employee
	 * getEmployeeByIds(@PathVariable("pinCode") int pinCode) {
	 * System.out.println("pinCode is :::::::::: " + pinCode); return null; //
	 * return empService.getEmployeeByIds(pinCode); }
	 */

}
