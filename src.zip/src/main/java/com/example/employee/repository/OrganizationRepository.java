/**
 * 
 */
package com.example.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.employee.model.Organization;

/**
 * The interface that extends the CRUD Repository. This interface can also
 * contain project specific methods that need to be implemented by the
 * implementing classes.
 * 
 * @author Sharanya
 *
 */
@Repository
public interface OrganizationRepository extends JpaRepository<Organization, Integer> {
	
	//public List<Organization> getAllOrganizations();

}
