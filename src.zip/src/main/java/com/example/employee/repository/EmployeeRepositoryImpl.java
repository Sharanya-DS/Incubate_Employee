package com.example.employee.repository;

public class EmployeeRepositoryImpl {

}
