/**
 * 
 */
package com.example.employee.repository;

/**
 * @author admin
 *
 */
public class AddressRepositoryImpl {

}
