package com.example.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.example.employee.model.Addresses;

/**
 * The interface that extends the CRUD Repository. This interface can also
 * contain project specific methods that need to be implemented by the
 * implementing classes.
 * 
 * @author Sharanya
 *
 */
public interface AddressRepository extends JpaRepository<Addresses, Integer> {

	public List<Addresses> findByemployeeId (int employeeId);
}
