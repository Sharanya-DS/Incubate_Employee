package com.example.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.ArrayList;
import java.util.List;

import com.example.employee.model.Employee;

/**
 * The interface that extends the CRUD Repository. This interface can also
 * contain project specific methods that need to be implemented by the
 * implementing classes.
 * 
 * @author Sharanya
 *
 */
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	
	//public List<Employee> findByOrgId(int org_id);
	
	//public List<Employee> findByPincode(int pincode);
}
