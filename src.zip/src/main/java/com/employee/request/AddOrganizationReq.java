package com.employee.request;

public class AddOrganizationReq {

	private int orgId;
	private String orgName;
	private int incubateId;

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public int getIncubateId() {
		return incubateId;
	}

	public void setIncubateId(int incubateId) {
		this.incubateId = incubateId;
	}

}
